﻿using System;

namespace GolgeLabirenti
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=== GOLGE LABIRENTI ===");
            string oyuncuAdi = OyuncuAdiAl();

            string sinifAdi = "";
            int oyuncuCan = 100;
            int maksimumCan = 100;
            int saldiriGucu = 15;
            int savunmaGucu = 2;
            int mevcutMana = 0;
            int maksimumMana = 0;

            SinifSecimiAl(oyuncuAdi, ref sinifAdi, ref oyuncuCan, ref maksimumCan, ref saldiriGucu, ref savunmaGucu, ref mevcutMana, ref maksimumMana);

            int altinMiktari = 10;
            int iksirSayisi = 2;
            int anahtarSayisi = 0;
            int gecilenOda = 0;
            bool yadigarAlindi = false;

            bool oyunAktif = true;
            const int MAX_TUR = 40;
            int turSayaci = 0;

            Random zar = new Random();

            string[] envanter = { "Bos", "Bos", "Bos", "Bos" };
            int envanterSayaci = 0;

            string[] canavarIsimleri = { "Golge Suikastcisi", "Karanlik Tayf", "Golge Muhafizi" };
            int[] canavarCanlari = { 40, 60, 80 };

            string[] ganimetIsimleri = { "Gumus Hancer (+4 Saldiri)", "Celik Kalkan (+3 Savunma)", "Alev Kilici (+5 Saldiri)", "Demir Zirh (+4 Savunma)" };
            int[] ganimetSaldiriBonus = { 4, 0, 5, 0 };
            int[] ganimetSavunmaBonus = { 0, 3, 0, 4 };

            Console.WriteLine($"\nHos geldin {sinifAdi} {oyuncuAdi}! Golge tuzaklarini ve karanlik yaratiklari asarak cikis kapisini bul.\n");

            while (oyunAktif)
            {
                turSayaci++;

                if (turSayaci > MAX_TUR)
                {
                    Console.WriteLine($"\n[!] Labirentin tavani coktu {oyuncuAdi}! Maksimum tur sinirina ulasildi. Oyun berabere bitti.");
                    oyunAktif = false;
                    break;
                }

                if (turSayaci > 1 && maksimumMana > 0 && mevcutMana < maksimumMana)
                {
                    int oncekiMana = mevcutMana;
                    mevcutMana = Math.Min(maksimumMana, mevcutMana + 15);
                    Console.WriteLine($"\n[~] {oyuncuAdi} odaklandi ve {mevcutMana - oncekiMana} mana yeniledi.");
                }

                DurumEkraniCiz(oyuncuAdi, sinifAdi, oyuncuCan, maksimumCan, saldiriGucu, savunmaGucu, mevcutMana, maksimumMana, altinMiktari, iksirSayisi, anahtarSayisi, gecilenOda, turSayaci, MAX_TUR, envanter);

                int secim = OdaSecimiAl(oyuncuAdi);

                if (secim == 3)
                {
                    if (iksirSayisi > 0)
                    {
                        iksirSayisi--;
                        oyuncuCan += 25;
                        if (oyuncuCan > maksimumCan) oyuncuCan = maksimumCan;
                        Console.WriteLine($"\n[+] {oyuncuAdi} sifa iksiri icti! Canin yenilendi. Bu tur dinlenerek gecti.");
                    }
                    else
                    {
                        Console.WriteLine("\n[!] Cantanda hic iksir kalmadi!");
                    }
                    continue;
                }

                gecilenOda++;
                Console.WriteLine($"\n--- {oyuncuAdi}, {gecilenOda}. Odaya Adim Atti ---");

                if (gecilenOda >= 5 && zar.Next(1, 101) <= 35)
                {
                    Console.WriteLine($"TEBRIKLER {oyuncuAdi.ToUpper()}! Gun isiginin sizdigi Labirent Cikis Kapisini buldun ve kurtuldun!");
                    Console.WriteLine($"Kahraman: {oyuncuAdi} ({sinifAdi}) | Toplam Altin: {altinMiktari} | Gecilen Oda: {gecilenOda}");
                    oyunAktif = false;
                    break;
                }

                int odaZari = zar.Next(1, 101);

                if (odaZari <= 20)
                {
                    Console.WriteLine("[SANDIK] Odanin kosesinde demir kilitli bir hazine sandigi buldun!");

                    if (anahtarSayisi > 0)
                    {
                        int sandikSecimi = SandikSecimiAl(anahtarSayisi);

                        if (sandikSecimi == 1)
                        {
                            anahtarSayisi--;

                            if (zar.Next(1, 101) <= 20)
                            {
                                Console.WriteLine($"[MIMIC!] {oyuncuAdi} anahtari cevirdigi an sandik golgelerin arasindan keskin dislerini cikardi! Bu bir Golge Mimic!");
                                SavasBaslat(zar, oyuncuAdi, sinifAdi, "Golge Mimic", 25, 2, ref oyuncuCan, saldiriGucu, savunmaGucu, ref mevcutMana, maksimumMana);

                                if (oyuncuCan > 0)
                                {
                                    int mimicAltin = zar.Next(10, 21);
                                    altinMiktari += mimicAltin;
                                    Console.WriteLine($"[GANIMET] Golge Mimic parcalandi, icinden {mimicAltin} altin topladin.");
                                }
                            }
                            else
                            {
                                int bulunanAltin = zar.Next(15, 31);
                                altinMiktari += bulunanAltin;
                                Console.WriteLine($"[ACILDI] Anahtari kullandin! Sandiktan {bulunanAltin} altin cikti.");

                                if (zar.Next(1, 101) <= 50)
                                {
                                    iksirSayisi++;
                                    Console.WriteLine("[IKSIR] Sandigin icinden 1 adet Sifa Iksiri buldun!");
                                }

                                if (envanterSayaci < envanter.Length)
                                {
                                    envanter[envanterSayaci] = ganimetIsimleri[envanterSayaci];
                                    saldiriGucu += ganimetSaldiriBonus[envanterSayaci];
                                    savunmaGucu += ganimetSavunmaBonus[envanterSayaci];
                                    Console.WriteLine($"[ESYA] Sandiktan '{envanter[envanterSayaci]}' cikti!");
                                    envanterSayaci++;
                                }
                                else
                                {
                                    iksirSayisi++;
                                    Console.WriteLine("[ESYA] Envanterin dolu oldugu icin sandiktaki yedek Sifa Iksirini aldin.");
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("Anahtarini saklamaya karar verdin ve sandigi acmadan ilerledin.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("[KILITLI] Cantanda hic anahtar olmadigi icin sandigi acamadin! Golge yaratiklarindan anahtar dusurebilirsin.");
                    }
                }
                else if (odaZari <= 40)
                {
                    int tuzakHasari = zar.Next(8, 16);
                    oyuncuCan -= tuzakHasari;
                    Console.WriteLine($"[TUZAK] Golgelerin arasindan firlayan oklar {oyuncuAdi} karakterine {tuzakHasari} hasar verdi!");
                }
                else if (odaZari <= 55)
                {
                    Console.WriteLine($"[TUCCAR] Los mesalenin altinda pelerinli bir Golge Tuccari {oyuncuAdi} icin tezgahini acti!");
                    TuccarOdasi(oyuncuAdi, ref altinMiktari, ref iksirSayisi, ref anahtarSayisi, ref saldiriGucu, ref savunmaGucu, envanter, ref envanterSayaci, ref yadigarAlindi);
                }
                else
                {
                    int dusmanIndex = zar.Next(0, canavarIsimleri.Length);
                    string aktifDusman = canavarIsimleri[dusmanIndex];
                    int dusmanCan = canavarCanlari[dusmanIndex];

                    Console.WriteLine($"[SAVAS] Karanlik golgelerin arasindan {oyuncuAdi} karsisina bir {aktifDusman} (Can: {dusmanCan}) cikti!");
                    SavasBaslat(zar, oyuncuAdi, sinifAdi, aktifDusman, dusmanCan, 6, ref oyuncuCan, saldiriGucu, savunmaGucu, ref mevcutMana, maksimumMana);

                    if (oyuncuCan > 0)
                    {
                        int ganimetAltin = zar.Next(10, 21);
                        altinMiktari += ganimetAltin;
                        Console.WriteLine($"[GANIMET] {aktifDusman} uzerinden {ganimetAltin} altin dustu.");

                        if (zar.Next(1, 101) <= 25)
                        {
                            anahtarSayisi++;
                            Console.WriteLine("[ANAHTAR] Yaratigin uzerinden 1 adet Labirent Anahtari dustu!");
                        }
                    }
                }

                if (oyuncuCan <= 0)
                {
                    Console.WriteLine($"\n[KAYBETTIN] {oyuncuAdi} can puanini tuketti ve golgeler icinde yenik dustu...");
                    oyunAktif = false;
                }
            }

            Console.WriteLine("\nOyun sona erdi. Cikmak icin bir tusa basin...");
            Console.ReadKey();
        }

        static void TuccarOdasi(string oyuncuAdi, ref int altinMiktari, ref int iksirSayisi, ref int anahtarSayisi, ref int saldiriGucu, ref int savunmaGucu, string[] envanter, ref int envanterSayaci, ref bool yadigarAlindi)
        {
            bool alisverisAktif = true;

            do
            {
                Console.WriteLine($"\n--- GOLGE TUCCARI (Mevcut Altin: {altinMiktari}) ---");
                Console.WriteLine("1 - Sifa Iksiri (15 Altin)");
                Console.WriteLine("2 - Labirent Anahtari (20 Altin)");

                if (yadigarAlindi)
                {
                    Console.WriteLine("3 - Golge Yadigari [SATIN ALINDI]");
                }
                else if (envanterSayaci >= envanter.Length)
                {
                    Console.WriteLine("3 - Golge Yadigari [ENVANTER DOLU]");
                }
                else
                {
                    Console.WriteLine("3 - Golge Yadigari [+3 Saldiri, +2 Savunma] (30 Altin)");
                }

                Console.WriteLine("4 - Alisverisi Bitir ve Yoluna Devam Et");
                Console.Write($"{oyuncuAdi}, secimin (1-4): ");

                string giris = Console.ReadLine();
                int secim;

                if (int.TryParse(giris, out secim) && secim >= 1 && secim <= 4)
                {
                    if (secim == 1)
                    {
                        if (altinMiktari >= 15)
                        {
                            altinMiktari -= 15;
                            iksirSayisi++;
                            Console.WriteLine("[+] 1 adet Sifa Iksiri satin aldin!");
                        }
                        else
                        {
                            Console.WriteLine("[!] Yetersiz altin! Sifa Iksiri icin 15 altin gerekiyor.");
                        }
                    }
                    else if (secim == 2)
                    {
                        if (altinMiktari >= 20)
                        {
                            altinMiktari -= 20;
                            anahtarSayisi++;
                            Console.WriteLine("[+] 1 adet Labirent Anahtari satin aldin!");
                        }
                        else
                        {
                            Console.WriteLine("[!] Yetersiz altin! Labirent Anahtari icin 20 altin gerekiyor.");
                        }
                    }
                    else if (secim == 3)
                    {
                        if (yadigarAlindi)
                        {
                            Console.WriteLine("[!] Bu ozel yadigari zaten satin aldin.");
                        }
                        else if (envanterSayaci >= envanter.Length)
                        {
                            Console.WriteLine("[!] Envanterinde bos yer kalmadigi icin bu esyayi alamazsin.");
                        }
                        else if (altinMiktari >= 30)
                        {
                            altinMiktari -= 30;
                            yadigarAlindi = true;
                            envanter[envanterSayaci] = "Golge Yadigari (+3 Sld / +2 Svn)";
                            envanterSayaci++;
                            saldiriGucu += 3;
                            savunmaGucu += 2;
                            Console.WriteLine("[+] Golge Yadigari envanterine eklendi! Saldiri +3, Savunma +2 artti.");
                        }
                        else
                        {
                            Console.WriteLine("[!] Yetersiz altin! Golge Yadigari icin 30 altin gerekiyor.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Golge Tuccari golgelerin arasina karisarak kayboldu.");
                        alisverisAktif = false;
                    }
                }
                else
                {
                    Console.WriteLine("Gecersiz secim! Lutfen 1 ile 4 arasinda bir rakam girin.");
                }

            } while (alisverisAktif);
        }

        static string OyuncuAdiAl()
        {
            string isim = "";
            bool gecerli = false;

            do
            {
                Console.Write("Kahramaninin adini gir: ");
                string giris = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(giris))
                {
                    isim = giris.Trim();
                    gecerli = true;
                }
                else
                {
                    Console.WriteLine("Isim bos birakilamaz! Lutfen bir karakter adi girin.\n");
                }
            } while (!gecerli);

            return isim;
        }

        static void SinifSecimiAl(string oyuncuAdi, ref string sinifAdi, ref int can, ref int maxCan, ref int saldiri, ref int savunma, ref int mana, ref int maxMana)
        {
            int secim;
            bool gecerli = false;

            do
            {
                Console.WriteLine($"\n{oyuncuAdi}, lutfen sinifini sec:");
                Console.WriteLine("1 - Savasci (Can: 125 | Saldiri: 15 | Savunma: 4 | Dayanikli yakin dovuscu)");
                Console.WriteLine("2 - Buyucu  (Can: 85  | Saldiri: 12 | Savunma: 1 | Mana: 100 | Ates Topu yetenegi ve her tur mana yenileme)");
                Console.WriteLine("3 - Korucu  (Can: 100 | Saldiri: 18 | Savunma: 2 | Cevik avci, daha yuksek kacinma sansi)");
                Console.Write("Sinif Seciminiz (1-3): ");

                string giris = Console.ReadLine();

                if (int.TryParse(giris, out secim) && secim >= 1 && secim <= 3)
                {
                    gecerli = true;
                }
                else
                {
                    Console.WriteLine("Gecersiz secim! Lutfen 1, 2 veya 3 girin.");
                }
            } while (!gecerli);

            if (secim == 1)
            {
                sinifAdi = "Savasci";
                can = 125;
                maxCan = 125;
                saldiri = 15;
                savunma = 4;
                mana = 0;
                maxMana = 0;
            }
            else if (secim == 2)
            {
                sinifAdi = "Buyucu";
                can = 85;
                maxCan = 85;
                saldiri = 12;
                savunma = 1;
                mana = 100;
                maxMana = 100;
            }
            else
            {
                sinifAdi = "Korucu";
                can = 100;
                maxCan = 100;
                saldiri = 18;
                savunma = 2;
                mana = 0;
                maxMana = 0;
            }
        }

        static void SavasBaslat(Random zar, string oyuncuAdi, string sinifAdi, string aktifDusman, int dusmanCan, int tabanHasar, ref int mevcutCan, int saldiriGucu, int savunmaGucu, ref int mevcutMana, int maksimumMana)
        {
            int savasTuru = 0;

            while (dusmanCan > 0 && mevcutCan > 0)
            {
                savasTuru++;

                if (savasTuru > 1 && maksimumMana > 0 && mevcutMana < maksimumMana)
                {
                    mevcutMana = Math.Min(maksimumMana, mevcutMana + 10);
                    Console.WriteLine($"[~] Savas sirasinda 10 mana yenilendi. (Guncel Mana: {mevcutMana}/{maksimumMana})");
                }

                int savasSecimi = SavasHamlesiAl(sinifAdi, mevcutMana, maksimumMana);
                bool savunmada = false;

                if (savasSecimi == 2)
                {
                    savunmada = true;
                    Console.WriteLine($"{oyuncuAdi} savunma pozisyonu aldi! Alacagi hasar yariya dusecek.");
                }
                else if (savasSecimi == 3)
                {
                    int kacinmaZari = zar.Next(1, 7);
                    int gerekenZar = (sinifAdi == "Korucu") ? 3 : 4;

                    if (kacinmaZari >= gerekenZar)
                    {
                        Console.WriteLine($"[Kacinma Zari: {kacinmaZari}] {oyuncuAdi} cevik bir hamleyle saldiridan tamamen kacindi!");
                        continue;
                    }
                    else
                    {
                        Console.WriteLine($"[Kacinma Zari: {kacinmaZari}] {oyuncuAdi} kacinmayi basaramadi, dusman acik buldu!");
                    }
                }
                else if (savasSecimi == 4 && sinifAdi == "Buyucu")
                {
                    mevcutMana -= 30;
                    int buyuZari = zar.Next(8, 17);
                    int buyuHasari = (saldiriGucu * 2) + buyuZari;
                    dusmanCan -= buyuHasari;
                    Console.WriteLine($"[ATES TOPU!] {oyuncuAdi} 30 mana harcadi ve {aktifDusman} hedefine {buyuHasari} buyu hasari vurdu! (Kalan Mana: {mevcutMana}/{maksimumMana} | Dusman Cani: {Math.Max(0, dusmanCan)})");

                    if (dusmanCan <= 0)
                    {
                        Console.WriteLine($"[ZAFER] {aktifDusman} alevler icinde yenildi!");
                        break;
                    }
                }
                else
                {
                    int verilenHasar = HasarHesapla(zar, saldiriGucu);
                    dusmanCan -= verilenHasar;
                    Console.WriteLine($"{oyuncuAdi}, {aktifDusman} hedefine {verilenHasar} hasar vurdu! (Kalan Can: {Math.Max(0, dusmanCan)})");

                    if (dusmanCan <= 0)
                    {
                        Console.WriteLine($"[ZAFER] {aktifDusman} yenildi!");
                        break;
                    }
                }

                int dusmanZari = zar.Next(1, 7);
                int hamHasar = tabanHasar + dusmanZari;
                int alinanHasar = Math.Max(1, hamHasar - savunmaGucu);

                if (savunmada)
                {
                    alinanHasar = Math.Max(1, alinanHasar / 2);
                    mevcutCan -= alinanHasar;
                    Console.WriteLine($"{aktifDusman} {dusmanZari} zar atti. Savunma sayesinde hasar yariya dustu ({alinanHasar} net hasar). {oyuncuAdi} Kalan Can: {Math.Max(0, mevcutCan)}");
                }
                else
                {
                    mevcutCan -= alinanHasar;
                    Console.WriteLine($"{aktifDusman} {dusmanZari} zar atti ({hamHasar} ham hasar - {savunmaGucu} savunma = {alinanHasar} net hasar). {oyuncuAdi} Kalan Can: {Math.Max(0, mevcutCan)}");
                }
            }
        }

        static void DurumEkraniCiz(string isim, string sinifAdi, int can, int maxCan, int saldiri, int savunma, int mana, int maxMana, int altin, int iksir, int anahtar, int oda, int tur, int maxTur, string[] envanter)
        {
            Console.WriteLine("\n================================================================================");
            string manaBilgisi = (maxMana > 0) ? $" | Mana: {mana}/{maxMana}" : "";
            Console.WriteLine($"Kahraman: {isim} ({sinifAdi}) | Tur: {tur}/{maxTur} | Oda: {oda}");
            Console.WriteLine($"Can: {can}/{maxCan}{manaBilgisi} | Saldiri: {saldiri} | Savunma: {savunma} | Altin: {altin} | Iksir: {iksir} | Anahtar: {anahtar}");
            Console.Write("Envanter: ");
            for (int i = 0; i < envanter.Length; i++)
            {
                Console.Write($"[{envanter[i]}] ");
            }
            Console.WriteLine("\n================================================================================");
        }

        static int OdaSecimiAl(string oyuncuAdi)
        {
            int secim;
            bool gecerli = false;

            do
            {
                Console.WriteLine($"{oyuncuAdi}, ne yapmak istersin?");
                Console.WriteLine("1 - Sol Kapidan Ilerle");
                Console.WriteLine("2 - Sag Kapidan Ilerle");
                Console.WriteLine("3 - Sifa Iksiri Ic (+25 Can)");
                Console.Write("Seciminiz (1-3): ");

                string giris = Console.ReadLine();

                if (int.TryParse(giris, out secim) && secim >= 1 && secim <= 3)
                {
                    gecerli = true;
                }
                else
                {
                    Console.WriteLine("Gecersiz secim! Lutfen yalnizca 1, 2 veya 3 rakamini girin.\n");
                }

            } while (!gecerli);

            return secim;
        }

        static int SandikSecimiAl(int mevcutAnahtar)
        {
            int secim;
            bool gecerli = false;

            do
            {
                Console.WriteLine($"Sandigi acmak ister misin? (Mevcut Anahtar: {mevcutAnahtar})");
                Console.WriteLine("1 - Anahtar Kullan ve Sandigi Ac");
                Console.WriteLine("2 - Sandigi Birak ve Yoluna Devam Et");
                Console.Write("Seciminiz (1-2): ");

                string giris = Console.ReadLine();

                if (int.TryParse(giris, out secim) && (secim == 1 || secim == 2))
                {
                    gecerli = true;
                }
                else
                {
                    Console.WriteLine("Gecersiz secim! Lutfen yalnizca 1 veya 2 rakamini girin.\n");
                }

            } while (!gecerli);

            return secim;
        }

        static int SavasHamlesiAl(string sinifAdi, int mevcutMana, int maksimumMana)
        {
            int savasSecimi;
            bool gecerli = false;
            int maxSecenek = (sinifAdi == "Buyucu") ? 4 : 3;

            do
            {
                if (sinifAdi == "Buyucu")
                {
                    Console.Write($"Hamlen (1: Saldir, 2: Savun [%50 Azaltma], 3: Kacin, 4: Ates Topu [30 Mana - Mevcut: {mevcutMana}/{maksimumMana}]): ");
                }
                else
                {
                    Console.Write("Hamlen (1: Saldir, 2: Savun [%50 Azaltma], 3: Kacin): ");
                }

                string girdi = Console.ReadLine();

                if (int.TryParse(girdi, out savasSecimi) && savasSecimi >= 1 && savasSecimi <= maxSecenek)
                {
                    if (savasSecimi == 4 && mevcutMana < 30)
                    {
                        Console.WriteLine("Yetersiz mana! Ates Topu atmak icin en az 30 manaya ihtiyacin var.");
                    }
                    else
                    {
                        gecerli = true;
                    }
                }
                else
                {
                    Console.WriteLine($"Hatali giris! Sadece 1 ile {maxSecenek} arasinda bir sayi girebilirsin.");
                }
            } while (!gecerli);

            return savasSecimi;
        }

        static int HasarHesapla(Random zar, int temelSaldiri)
        {
            int atilanZar = zar.Next(1, 7);
            int toplamHasar = temelSaldiri + atilanZar;

            Console.Write($"[Zar: {atilanZar}] ");

            if (atilanZar == 6)
            {
                toplamHasar *= 2;
                Console.Write("[KRITIK VURUS!] ");
            }

            return toplamHasar;
        }
    }
}